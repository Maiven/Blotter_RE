# 주석 (comment)
1 + 1 # 더하기 ㅋㅋㅋ
1 + 1

#### 1. 시작하기 ####

#### 2. 파일 읽어오기 ####

x = 1
y <- 1

10 > 20

"감자" == "고구마" # equal
"감자" != "고구마" # not equal


round(23.45)
round(23.45, 1)
round(23.45, 2)
round(23.45, -1)
floor(123.9)
ceiling(12.01)

?round

1:5
3:-6

1:3
seq(1, 3)
seq(1, 3, 1)
seq(from = 1, to = 3, by = 1)
seq(from = 1, to = 3, by = 0.5)
seq(from = 1, to = 3, length.out = 9)

rep(1:3, 3)
rep(3, 1:3)
rep(x = 1:3, times = 3)
rep(times = 3, x = 1:3)
?rep

"hi"

# install.packages("beepr")
library("beepr")
beep(2)

getwd()
list.files()

install.packages("imager")
library("imager")
img = load.image("sample_cat_image.jpg")
dim(img)
img[1:3, 1:3, 1, 1]
plot(img)

img[,,, 1] = 1 - img[,,, 1]
plot(img)

img[,,, 2] = 1 - img[,,, 2]
img[,,, 3] = 1 - img[,,, 3]
plot(img)

install.packages("ggplot2")
install.packages("plotly")

library("ggplot2")
df = data.frame(xx = 1:10,
                yy = 1:10)
gg = ggplot(data = df,
            aes(x = xx, 
                y = yy)) + 
  geom_point(size = 5)

library("plotly")
ggplotly(gg)

df = read.csv("finance_indices_2007_2018.csv",
              sep = "#",
              encoding = "CP949")
head(df, 2)
head(df)
tail(df, 2)

# install.packages("excel.link")
# library("excel.link")
# xlrc[["a1"]] = 1:10
# xl.sheet.add("new")
# xl.sheet.delete("Sheet1")

str(df) # 구조.
summary(df)
nrow(df)
ncol(df)
colnames(df) # 변수명 변경 가능

df$index_usa
df$index_usa[985] # 같음
df[985, "index_usa"] # 같음

df[1, ] # df 객체에서 첫 번째 row를 출력
# df라는 이름의 data.frame객체에서 첫 번째 row, 
#  모든 column 출력
df[c(1, 3, 5), ]

df[1:3, ] # 같음
df[c(1, 2, 3), ] # 같음

df[1:2, 1:3]
df[1:2, c("monthly", "date")]
df[1:2, "foreign"]
df[1:2, c("monthly", "index_usa")]

install.packages("ggplot2")
library("ggplot2")
data("diamonds")
head(diamonds, 2)
class(diamonds)
class(1)
class("text")
class(df)

as.numeric("123") # as: ~화.
as.numeric("text")
as.character(123)
dia = as.data.frame(diamonds)
class(dia)

library("data.table")
as.numeric("text")
"a" + 1

head(dia, 2)
c(1, 2, 3)
length(c(1, 2, 3)) # 1차원 벡터의 원소의 개수->길이
unique(c("a", "a", "b")) # 중복제거된 고유한 값(원소 등)
unique(dia$color)
table(dia$color)
table(dia$color, dia$cut)
head(dia, 2)

prop.table(table(dia$color))
round(prop.table(table(dia$color)) * 100, 2)
dia_tbl = as.data.frame(prop.table(table(dia$color)))
dia_tbl

dia_tbl[, "Freq"] = round(dia_tbl$Freq * 100, 2)
dia_tbl
# Q. 첫 번째 변수명을 Color로,
#    두 번째 변수명을 Ratio로 변경하시오.
# (단, 두줄 이하의 코드로 변경)
# 힌트, c()
colnames(dia_tbl)[1] = "Color"
colnames(dia_tbl)[2] = "Ratio"
colnames(dia_tbl) = c("Color", "Ratio")
dia_tbl

ggplot(data = dia_tbl,
       aes(x = Color,
           y = Ratio,
           fill = Color)) + 
  geom_col()

write.csv(dia_tbl, "diamonds_color_ratio.csv",
          row.names = FALSE)

write.csv(diamonds, "diamonds.csv",
          row.names = FALSE)

for(n in 1:3){
  print(n)
}

for(n in c(2, 4, 7)){
  print(n)
}

for(num in c("a", "b", "d")){
  print(n)
}
# [[ 코드에서의 괄호 사용 ]]
# 소괄호(): 수학 연산의 우선순위, 함수 뒤에 인자를 받을 때
# 중괄호{}: 여러줄의 코드를 묶을 때
# 대괄호[]: 객체 내부 정보를 추출할 때(인덱싱, 색인)

list.files()
listt = list.files()
for(path in listt){
  print(path)
  Sys.sleep(2)
}

list.files(pattern = "csv")

df = read.csv("elec_load.csv", stringsAsFactors = FALSE)
head(df, 2)

table(df$YEAR)
df_2010 = df[df$YEAR == 2010, ]
head(df_2010, 2)

for(year in unique(df$YEAR)){
  df_sub = df[df$YEAR == year, ]
  write.csv(df_sub, paste0("elec_load_year_", year, ".csv"),
            row.names = FALSE)
}
paste0("elec_load_year_", 2017, ".csv")

# install.packages("xlsx")
library("xlsx")
write.xlsx(df, "elec_load_sheet_2017.xlsx",
           sheetName = "2017", row.names = FALSE)

for(year in unique(df$YEAR)){
  print(year)
  df_sub = df[df$YEAR == year, ]
  write.xlsx(df_sub, "elec_load_sheet.xlsx",
             sheetName = as.character(year), 
             append = TRUE,
             row.names = FALSE)
}

strptime("#$2019@@12@@02", format = "#$%Y@@%m@@%d")
strptime("2019년 12월 2일", format = "%Y년 %m월 %d일")
as.Date(43799, origin = "1900-01-01")

# install.packages("lubridate")
library("lubridate")
bike = read.csv("bike.csv", 
                stringsAsFactors = FALSE)
head(bike, 2)

bike[, "month"] = month(bike$datetime)
bike[, "hour" ] =  hour(bike$datetime)
bike[, "wday" ] =  wday(bike$datetime, 
                        week_start = 1) # 월요일이 1
head(bike, 2)

bike[, "wend"] = ifelse(bike$wday >= 6, 
                        yes = 1, 
                        no = 0)
table(bike$wday, bike$wend)

agg_reg = aggregate(data = bike,
                    registered ~ hour,
                    FUN = "mean")
head(agg_reg)

ggplot(data = agg_reg,
       aes(x = hour, y = registered,
           fill = registered)) + 
  geom_col()

# write.csv(bike, "bike_hour.csv",
#           row.names = FALSE)

agg_casual = aggregate(data = bike,
                    casual ~ hour,
                    FUN = "mean")
head(agg_casual)

ggplot(data = agg_casual,
       aes(x = hour, y = casual,
           fill = casual)) + 
  geom_col()

# count = casual + registered

agg_casual = aggregate(data = bike,
                       casual ~ wday,
                       FUN = "mean")
head(agg_casual)

ggplot(data = agg_casual,
       aes(x = wday, y = casual,
           fill = casual)) + 
  geom_col()

agg_reg = aggregate(data = bike,
                    registered ~ wday,
                    FUN = "mean")
head(agg_reg)

ggplot(data = agg_reg,
       aes(x = wday, y = registered,
           fill = registered)) + 
  geom_col()


elec = read.csv("elec_load.csv",
                stringsAsFactors = FALSE)
elec[, "AVG"] = apply(elec[, 4:27],
                      MARGIN = 1, 
                      FUN = "mean")
head(elec, 2)

ggplot(data = elec,
       aes(x = 1:nrow(elec),
           y = AVG,
           color = AVG)) + 
  geom_line()

ga = read.csv("GA_bounce_rate_sample.csv",
              stringsAsFactors = FALSE)
head(ga, 2)

ga_or = ga[grep(pattern = "\\(", x = ga$source), ]
head(ga_or) # 엔터 위 원표시.

bike = read.csv("bike.csv", stringsAsFactors = FALSE)
cor(bike$temp, bike$atemp)
cor.test(bike$temp, bike$atemp)

ggplot(data = bike,
       aes(x = temp,
           y = atemp)) + 
  geom_point()
