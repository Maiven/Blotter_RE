#### google map ####
# install.packages("ggmap")
library("ggmap")

register_google(key = "AIzaSyD5s8X0J17w5HshHGqYhdDucdACbqhQy1I")

gc = geocode(enc2utf8("서울특별시 선릉역")) # Geocoding API 필요
gc = as.data.frame(gc)
gc


map = get_googlemap(center = c(127.049, 37.50449),
                    maptype = "roadmap",
                    zoom = 15,
                    size = c(640, 640))
ggmap(map)


?geocode
geocode(enc2utf8("서울특별시 선릉역"),
        output = "latlona")
geocode(enc2utf8("서울특별시 선릉역"),
        output = "more")
geocode(enc2utf8("서울특별시 선릉역"),
        output = "all")

loc_sub = geocode(enc2utf8("서울특별시 선릉역 2번 출구"),
                  output = "more")
loc_sub = as.data.frame(loc_sub)
loc_sub

map = get_googlemap(center = as.numeric(loc_sub[1, 1:2]),
                    maptype = "roadmap",
                    zoom = 15,
                    size = c(320, 320),
                    markers = loc_sub[1, 1:2])
ggmap(map)
